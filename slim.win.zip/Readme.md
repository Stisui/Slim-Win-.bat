Warning This Script Is Dangerous
Recommended use virtual machines to runing this progarms